package com.code.project.biz.dao.impl;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


public class BaseDAOImpl extends SqlMapClientDaoSupport {
}
