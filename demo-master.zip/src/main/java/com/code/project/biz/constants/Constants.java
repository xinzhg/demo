package com.code.project.biz.constants;

/**
 * Created with IntelliJ IDEA.
 * User: zhangxin
 * Date: 13-7-22
 * Time: 下午3:41
 * To change this template use File | Settings | File Templates.
 */
public class Constants {

    public static final int NO_RIGHT = 0;

    public static final int HAS_RIGHT = 1;

}
