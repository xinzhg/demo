1.import test.sql to mysql

2.modify /etc/hosts   
  add   127.0.0.1 demo.com


3.run:  mvn tomcat7:run

4.input http://demo.com:8088/index  on chrome
